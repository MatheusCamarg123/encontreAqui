﻿
namespace ProjetoIntegrador
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.llbl1 = new System.Windows.Forms.Label();
            this.llbl2 = new System.Windows.Forms.Label();
            this.llbl3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblF2 = new System.Windows.Forms.Label();
            this.lblO = new System.Windows.Forms.Label();
            this.lblA = new System.Windows.Forms.Label();
            this.lblF = new System.Windows.Forms.Label();
            this.lblAmeaças = new System.Windows.Forms.Label();
            this.lblFraqueza = new System.Windows.Forms.Label();
            this.lblOportunidade = new System.Windows.Forms.Label();
            this.lblForça = new System.Windows.Forms.Label();
            this.APIs = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Imobiliaria = new System.Windows.Forms.TextBox();
            this.Respon = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Funcionarios = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(12, 9);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(348, 25);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "- Definição do objetivo do sistema: ";
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl.Location = new System.Drawing.Point(11, 96);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(242, 25);
            this.lbl.TabIndex = 1;
            this.lbl.Text = "- Requisitos funcionais: ";
            this.lbl.Click += new System.EventHandler(this.lbl_Click);
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(11, 182);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(278, 25);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "- Requisitos não funcionais:";
            // 
            // llbl1
            // 
            this.llbl1.AutoSize = true;
            this.llbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbl1.Location = new System.Drawing.Point(13, 34);
            this.llbl1.Name = "llbl1";
            this.llbl1.Size = new System.Drawing.Size(18, 25);
            this.llbl1.TabIndex = 3;
            this.llbl1.Text = ".";
            this.llbl1.Click += new System.EventHandler(this.llbl1_Click);
            // 
            // llbl2
            // 
            this.llbl2.AutoSize = true;
            this.llbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbl2.Location = new System.Drawing.Point(11, 121);
            this.llbl2.Name = "llbl2";
            this.llbl2.Size = new System.Drawing.Size(18, 25);
            this.llbl2.TabIndex = 4;
            this.llbl2.Text = ".";
            // 
            // llbl3
            // 
            this.llbl3.AutoSize = true;
            this.llbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbl3.Location = new System.Drawing.Point(11, 207);
            this.llbl3.Name = "llbl3";
            this.llbl3.Size = new System.Drawing.Size(18, 25);
            this.llbl3.TabIndex = 5;
            this.llbl3.Text = ".";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.panel3.ForeColor = System.Drawing.Color.Blue;
            this.panel3.Location = new System.Drawing.Point(432, 294);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 345);
            this.panel3.TabIndex = 29;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.panel4.ForeColor = System.Drawing.Color.Blue;
            this.panel4.Location = new System.Drawing.Point(12, 486);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(782, 10);
            this.panel4.TabIndex = 28;
            // 
            // lblF2
            // 
            this.lblF2.AutoSize = true;
            this.lblF2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblF2.Location = new System.Drawing.Point(448, 329);
            this.lblF2.Name = "lblF2";
            this.lblF2.Size = new System.Drawing.Size(18, 25);
            this.lblF2.TabIndex = 27;
            this.lblF2.Text = ".";
            // 
            // lblO
            // 
            this.lblO.AutoSize = true;
            this.lblO.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblO.Location = new System.Drawing.Point(12, 537);
            this.lblO.Name = "lblO";
            this.lblO.Size = new System.Drawing.Size(18, 25);
            this.lblO.TabIndex = 26;
            this.lblO.Text = ".";
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA.Location = new System.Drawing.Point(448, 537);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(18, 25);
            this.lblA.TabIndex = 25;
            this.lblA.Text = ".";
            // 
            // lblF
            // 
            this.lblF.AutoSize = true;
            this.lblF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblF.Location = new System.Drawing.Point(12, 329);
            this.lblF.Name = "lblF";
            this.lblF.Size = new System.Drawing.Size(18, 25);
            this.lblF.TabIndex = 24;
            this.lblF.Text = ".";
            // 
            // lblAmeaças
            // 
            this.lblAmeaças.AutoSize = true;
            this.lblAmeaças.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmeaças.Location = new System.Drawing.Point(448, 499);
            this.lblAmeaças.Name = "lblAmeaças";
            this.lblAmeaças.Size = new System.Drawing.Size(101, 25);
            this.lblAmeaças.TabIndex = 23;
            this.lblAmeaças.Text = "Ameaças";
            // 
            // lblFraqueza
            // 
            this.lblFraqueza.AutoSize = true;
            this.lblFraqueza.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFraqueza.Location = new System.Drawing.Point(448, 294);
            this.lblFraqueza.Name = "lblFraqueza";
            this.lblFraqueza.Size = new System.Drawing.Size(114, 25);
            this.lblFraqueza.TabIndex = 22;
            this.lblFraqueza.Text = "Fraquezas";
            // 
            // lblOportunidade
            // 
            this.lblOportunidade.AutoSize = true;
            this.lblOportunidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOportunidade.Location = new System.Drawing.Point(12, 499);
            this.lblOportunidade.Name = "lblOportunidade";
            this.lblOportunidade.Size = new System.Drawing.Size(153, 25);
            this.lblOportunidade.TabIndex = 21;
            this.lblOportunidade.Text = "Oportunidades";
            // 
            // lblForça
            // 
            this.lblForça.AutoSize = true;
            this.lblForça.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblForça.Location = new System.Drawing.Point(9, 294);
            this.lblForça.Name = "lblForça";
            this.lblForça.Size = new System.Drawing.Size(67, 25);
            this.lblForça.TabIndex = 20;
            this.lblForça.Text = "Força";
            // 
            // APIs
            // 
            this.APIs.AutoSize = true;
            this.APIs.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.APIs.Location = new System.Drawing.Point(9, 672);
            this.APIs.Name = "APIs";
            this.APIs.Size = new System.Drawing.Size(18, 25);
            this.APIs.TabIndex = 31;
            this.APIs.Text = ".";
            this.APIs.Click += new System.EventHandler(this.label1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 647);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 25);
            this.label1.TabIndex = 32;
            this.label1.Text = "- Lista de API";
            // 
            // Imobiliaria
            // 
            this.Imobiliaria.Location = new System.Drawing.Point(1026, 45);
            this.Imobiliaria.Name = "Imobiliaria";
            this.Imobiliaria.Size = new System.Drawing.Size(115, 20);
            this.Imobiliaria.TabIndex = 33;
            this.Imobiliaria.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Respon
            // 
            this.Respon.AutoSize = true;
            this.Respon.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Respon.Location = new System.Drawing.Point(1031, 203);
            this.Respon.Name = "Respon";
            this.Respon.Size = new System.Drawing.Size(19, 29);
            this.Respon.TabIndex = 34;
            this.Respon.Text = ".";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DimGray;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(1026, 149);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 42);
            this.button1.TabIndex = 35;
            this.button1.Text = "Verificar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Funcionarios
            // 
            this.Funcionarios.Location = new System.Drawing.Point(1012, 102);
            this.Funcionarios.Name = "Funcionarios";
            this.Funcionarios.Size = new System.Drawing.Size(171, 20);
            this.Funcionarios.TabIndex = 36;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1021, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 25);
            this.label2.TabIndex = 37;
            this.label2.Text = "Imobiliária";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1003, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 25);
            this.label3.TabIndex = 38;
            this.label3.Text = "Nº Funcionários";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 831);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Funcionarios);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Respon);
            this.Controls.Add(this.Imobiliaria);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.APIs);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.lblF2);
            this.Controls.Add(this.lblO);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.lblF);
            this.Controls.Add(this.lblAmeaças);
            this.Controls.Add(this.lblFraqueza);
            this.Controls.Add(this.lblOportunidade);
            this.Controls.Add(this.lblForça);
            this.Controls.Add(this.llbl3);
            this.Controls.Add(this.llbl2);
            this.Controls.Add(this.llbl1);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.lbl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label llbl1;
        private System.Windows.Forms.Label llbl2;
        private System.Windows.Forms.Label llbl3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblF2;
        private System.Windows.Forms.Label lblO;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblF;
        private System.Windows.Forms.Label lblAmeaças;
        private System.Windows.Forms.Label lblFraqueza;
        private System.Windows.Forms.Label lblOportunidade;
        private System.Windows.Forms.Label lblForça;
        private System.Windows.Forms.Label APIs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Imobiliaria;
        private System.Windows.Forms.Label Respon;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Funcionarios;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

